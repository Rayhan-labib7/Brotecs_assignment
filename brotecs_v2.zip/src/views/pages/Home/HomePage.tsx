import React from 'react'

const HomePage = () => {
  return (
    <div className='w-full h-[600px] bg-white rounded-md mt-5'>
      HomePage</div>
  )
}

export default HomePage