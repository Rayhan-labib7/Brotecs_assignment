const Loader = () => (
  <div style={{ textAlign: 'center', padding: '20px' }}>
    <span>Loading...</span>
  </div>
);

export default Loader;
